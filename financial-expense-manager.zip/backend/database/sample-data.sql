-- ===================================================================
-- Financial Expense Manager - Sample Data
-- NOTE: For security, create real users via the /api/register endpoint
-- This inserts a demo user with a pre-hashed password 'Password123!'
-- ===================================================================
USE fem_db;

-- Demo user (password hash generated with PHP password_hash)
INSERT INTO users (name, email, password_hash)
VALUES ('Demo User', 'demo@example.com',
        '$2y$10$Z3QBo9rI9m3zjZ6o0ZzV5u0nQeRzJkq3m2m0b6nq4o3v7mX2kqW6.');

-- Ensure a budget row
INSERT INTO budgets (user_id, monthly_income, daily_budget, savings_goal)
SELECT id, 3000.00, 50.00, 500.00 FROM users WHERE email='demo@example.com'
ON DUPLICATE KEY UPDATE
  monthly_income=VALUES(monthly_income),
  daily_budget=VALUES(daily_budget),
  savings_goal=VALUES(savings_goal);

-- Some expenses
INSERT INTO expenses (user_id, description, amount, category, spend_date)
SELECT id, 'Lunch at Cafeteria', 15.00, 'food', CURRENT_DATE() FROM users WHERE email='demo@example.com';
INSERT INTO expenses (user_id, description, amount, category, spend_date)
SELECT id, 'Trotro fare to campus', 3.50, 'transport', CURRENT_DATE() FROM users WHERE email='demo@example.com';
INSERT INTO expenses (user_id, description, amount, category, spend_date)
SELECT id, 'Textbook purchase', 85.00, 'books', DATE_FORMAT(CURRENT_DATE(), '%Y-%m-01') FROM users WHERE email='demo@example.com';

-- Some savings
INSERT INTO savings (user_id, amount, note, save_date)
SELECT id, 200.00, 'Emergency fund', DATE_FORMAT(CURRENT_DATE(), '%Y-%m-01') FROM users WHERE email='demo@example.com';
INSERT INTO savings (user_id, amount, note, save_date)
SELECT id, 150.00, 'Monthly savings', CURRENT_DATE() FROM users WHERE email='demo@example.com';