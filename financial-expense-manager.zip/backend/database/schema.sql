-- ===================================================================
-- Financial Expense Manager - Database Schema (MySQL 8+)
-- Database: fem_db
-- ===================================================================
-- Safe defaults
SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET sql_notes = 0;

-- Create database (optional)
CREATE DATABASE IF NOT EXISTS fem_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE fem_db;

-- Drop existing tables (for idempotency during development)
DROP TABLE IF EXISTS user_tokens;
DROP TABLE IF EXISTS savings;
DROP TABLE IF EXISTS expenses;
DROP TABLE IF EXISTS budgets;
DROP TABLE IF EXISTS users;

-- Users
CREATE TABLE users (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name          VARCHAR(120)    NOT NULL,
    email         VARCHAR(191)    NOT NULL UNIQUE,
    password_hash VARCHAR(255)    NOT NULL,
    created_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB;

-- Budgets (one row per user; use upsert to update)
CREATE TABLE budgets (
    user_id         BIGINT UNSIGNED NOT NULL,
    monthly_income  DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    daily_budget    DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    savings_goal    DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    CONSTRAINT fk_budget_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Expenses
CREATE TABLE expenses (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     BIGINT UNSIGNED NOT NULL,
    description VARCHAR(255)    NOT NULL,
    amount      DECIMAL(12,2)   NOT NULL,
    category    VARCHAR(64)     NOT NULL,
    spend_date  DATE            NOT NULL,
    created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_exp_user_date (user_id, spend_date),
    KEY idx_exp_user_cat (user_id, category),
    CONSTRAINT fk_exp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Savings
CREATE TABLE savings (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     BIGINT UNSIGNED NOT NULL,
    amount      DECIMAL(12,2)   NOT NULL,
    note        VARCHAR(255)    NULL,
    save_date   DATE            NOT NULL,
    created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_sav_user_date (user_id, save_date),
    CONSTRAINT fk_sav_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Session tokens (simple token auth)
CREATE TABLE user_tokens (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id     BIGINT UNSIGNED NOT NULL,
    token       CHAR(64)        NOT NULL UNIQUE,
    expires_at  DATETIME        NOT NULL,
    created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_tok_user (user_id),
    CONSTRAINT fk_tok_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Helpful views
DROP VIEW IF EXISTS v_monthly_expense_sums;
CREATE VIEW v_monthly_expense_sums AS
  SELECT user_id,
         DATE_FORMAT(spend_date, '%Y-%m') AS ym,
         SUM(amount) AS total_amount
  FROM expenses
  GROUP BY user_id, ym;

DROP VIEW IF EXISTS v_monthly_savings_sums;
CREATE VIEW v_monthly_savings_sums AS
  SELECT user_id,
         DATE_FORMAT(save_date, '%Y-%m') AS ym,
         SUM(amount) AS total_amount
  FROM savings
  GROUP BY user_id, ym;

SET sql_notes = 1;