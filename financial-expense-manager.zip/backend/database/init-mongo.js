
// MongoDB initialization script
db = db.getSiblingDB("financial_expense_manager");

db.createCollection("users");
db.createCollection("expenses");
db.createCollection("budgets");
db.createCollection("savings");

db.users.insertOne({ username: "admin", password: "hashed_password", role: "admin" });
db.expenses.insertOne({ userId: "1", category: "Food", amount: 50, date: new Date() });
db.budgets.insertOne({ userId: "1", category: "Food", limit: 300 });
db.savings.insertOne({ userId: "1", goal: "Emergency Fund", target: 1000, saved: 200 });
