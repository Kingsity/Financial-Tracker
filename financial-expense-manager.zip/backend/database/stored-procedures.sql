-- ===================================================================
-- Financial Expense Manager - Stored Procedures & Functions (MySQL 8+)
-- ===================================================================
USE fem_db;
DELIMITER $$

-- Get monthly overview for a user (expenses, savings, income, savings rate)
DROP PROCEDURE IF EXISTS sp_get_monthly_overview $$
CREATE PROCEDURE sp_get_monthly_overview(IN p_user_id BIGINT UNSIGNED, IN p_year_month CHAR(7))
BEGIN
  DECLARE v_expenses DECIMAL(12,2) DEFAULT 0.00;
  DECLARE v_savings  DECIMAL(12,2) DEFAULT 0.00;
  DECLARE v_income   DECIMAL(12,2) DEFAULT 0.00;
  SELECT IFNULL(SUM(amount),0) INTO v_expenses
    FROM expenses
    WHERE user_id = p_user_id AND DATE_FORMAT(spend_date, '%Y-%m') = p_year_month;
  SELECT IFNULL(SUM(amount),0) INTO v_savings
    FROM savings
    WHERE user_id = p_user_id AND DATE_FORMAT(save_date, '%Y-%m') = p_year_month;
  SELECT monthly_income INTO v_income
    FROM budgets WHERE user_id = p_user_id;
  SELECT v_expenses AS total_expenses,
         v_savings  AS total_savings,
         v_income   AS monthly_income,
         CASE WHEN v_income > 0 THEN ROUND((v_savings / v_income) * 100, 2) ELSE 0 END AS savings_rate_pct;
END $$

-- Insert expense helper
DROP PROCEDURE IF EXISTS sp_add_expense $$
CREATE PROCEDURE sp_add_expense(
  IN p_user_id BIGINT UNSIGNED,
  IN p_description VARCHAR(255),
  IN p_amount DECIMAL(12,2),
  IN p_category VARCHAR(64),
  IN p_spend_date DATE
)
BEGIN
  INSERT INTO expenses (user_id, description, amount, category, spend_date)
  VALUES (p_user_id, p_description, p_amount, p_category, p_spend_date);
  SELECT LAST_INSERT_ID() AS new_expense_id;
END $$

-- Insert saving helper
DROP PROCEDURE IF EXISTS sp_add_saving $$
CREATE PROCEDURE sp_add_saving(
  IN p_user_id BIGINT UNSIGNED,
  IN p_amount DECIMAL(12,2),
  IN p_note VARCHAR(255),
  IN p_save_date DATE
)
BEGIN
  INSERT INTO savings (user_id, amount, note, save_date)
  VALUES (p_user_id, p_amount, p_note, p_save_date);
  SELECT LAST_INSERT_ID() AS new_saving_id;
END $$

DELIMITER ;