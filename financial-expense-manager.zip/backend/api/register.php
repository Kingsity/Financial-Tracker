<?php
// backend/api/register.php
require_once __DIR__ . '/../php/config.php';
require_once __DIR__ . '/../php/auth.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $name = trim($input['name'] ?? '');
    $email = trim($input['email'] ?? '');
    $password = (string)($input['password'] ?? '');
    $res = register_user($name, $email, $password);
    if ($res['ok']) {
        json_response(['message' => 'Registered', 'user_id' => $res['user_id']]);
    } else {
        json_response(['error' => $res['error']], 400);
    }
} else {
    json_response(['error' => 'Method not allowed'], 405);
}
?>