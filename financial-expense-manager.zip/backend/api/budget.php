<?php
// backend/api/budget.php
require_once __DIR__ . '/../php/config.php';
require_once __DIR__ . '/../php/budget.php';

$user = require_auth();
$user_id = (int)$user['user_id'];
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $row = get_budget($user_id);
    json_response($row);
} elseif ($method === 'PUT' || $method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    $monthly_income = (float)($input['monthly_income'] ?? 0);
    $daily_budget   = (float)($input['daily_budget'] ?? 0);
    $savings_goal   = (float)($input['savings_goal'] ?? 0);
    update_budget($user_id, $monthly_income, $daily_budget, $savings_goal);
    json_response(['updated' => true]);
} else {
    json_response(['error' => 'Method not allowed'], 405);
}
?>